package com.noor.mvvm.single_move_details

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.noor.mvvm.R

class SingleMoveDetaqils : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_single_move_detaqils)
    }
}